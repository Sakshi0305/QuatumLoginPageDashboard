function togglecheckbox(element) {
  element.classList.toggle("checked");
}
function toggleradio(element) {
  element.classList.toggle("checked");
}
